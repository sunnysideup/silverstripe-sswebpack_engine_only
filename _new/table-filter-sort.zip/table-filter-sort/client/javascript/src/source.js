import $ from 'jquery'

//
import './lib/string'
import './lib/dom'
import './lib/event'

//
import { inputs } from './lib/inputs'
import * as startup from './lib/startup'
import * as collectors from './lib/collectors'
import * as listeners from './lib/listeners'
import * as filterform from './lib/filterform'
import * as manipulations from './lib/manipulations'
import * as scrolling from './lib/scrolling'
import * as calculations from './lib/calculations'
import * as urls from './lib/urls'
import * as helpers from './lib/helpers'

//
import './lib/bootstrap'

//
export const tableFilterSort = (selector, config) => {
  const Els = document.querySelectorAll(selector)

  Els.forEach(El => {
    const private_api = {
      ...inputs($(El), config),

      ...startup,
      ...collectors,
      ...listeners,
      ...filterform,
      ...manipulations,
      ...scrolling,
      ...calculations,
      ...urls,
      ...helpers,
    }
    private_api.init()

    const public_api = {
      getVar: function(variableName) {
        if (private_api.hasOwnProperty(variableName)) {
          return private_api[variableName]
        }
      },
      setVar: function(variableName, value) {
        private_api[variableName] = value
        return this
      },
      reloadCurrentPage: function(pageNumber) {
        private_api.reloadCurrentPage()
        return this
      },
      gotoPage: function(pageNumber) {
        private_api.gotoPage(pageNumber)
        return this
      },
      reloadCurrentSelection: function() {
        private_api.gotoPage(0, true)
        return this
      },
      updateDataDictionaryForCategoryRow: function(category, rowID, newValue) {
        private_api.replaceRowValue(category, rowID, newValue)
        return this
      },
      updateMatchingRowsInDataDictionary: function(category, newValue) {
        private_api.updateMatchingRowsInDataDictionary(category, newValue)
        return this
      },
      resetAll: function() {
        private_api.resetAll()
        return this
      },
    }

    return public_api
  })
}

window.tableFilterSort = tableFilterSort
